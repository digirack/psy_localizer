# Changelog

## 2.2.0

### Changes

1. **Jalali dates in the Carts section**
   - Added the PrestaShop 9 `actionCartGridDataModifier` integration.
   - Cart list date values can be displayed in the Jalali calendar when Jalali date support is enabled.
   - Stored database dates are not changed.

2. **PHP 8.4 compatibility and PHP fixes**
   - Updated affected module code for modern PHP compatibility.
   - Removed/avoided legacy patterns that can cause errors on PHP 8.4.
   - Module requirements remain PHP 8.1+ and PrestaShop 9.x.

3. **RTL switch display fix**
   - Fixed the checked-state positioning of PrestaShop `.ps-switch` controls in RTL mode.
   - The fix is scoped to the switch presentation and does not change the global RTL direction.

4. **Google structured-data currency fix**
   - JSON-LD `priceCurrency` is converted from `IRT` to ISO `IRR`.
   - Schema price values are converted from Toman to Rial by multiplying Schema-only price fields by 10.
   - Visible prices, cart totals, checkout/payment amounts, database prices, and the store currency configuration are not modified by this Schema transformation.

### Compatibility

- PrestaShop: 9.x (tested target: 9.1.5)
- PHP: 8.1+
- PHP 8.4 compatibility fixes included
