<?php

function upgrade_module_2_2_0($module)
{
    // No database migration is required for 2.1.17.
    // Preserve the existing RTL switch positioning and override only the checked state.
    // Only JSON-LD structured-data prices are converted from IRT to IRR x10.
    // Register the PrestaShop 9 Carts grid data modifier so Jalali dates
    // are applied to the Carts list without changing stored database dates.
    return true;
}
