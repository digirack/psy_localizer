<?php
/**
 * ShelfBazar editorial page.
 *
 * @license Academic Free License 3.0
 */

class Psy_LocalizerSchemajsonldModuleFrontController extends ModuleFrontController
{
    /** @var bool */
    public $ssl = true;

    /**
     * Supported editorial languages. If the current shop language is not in
     * this list, English is rendered as the safe fallback.
     */
    private const SUPPORTED_LANGUAGES = ['fa', 'en', 'fr', 'es'];

    public function initContent()
    {
        parent::initContent();

        $iso = (string) $this->context->language->iso_code;
        $language = in_array($iso, self::SUPPORTED_LANGUAGES, true) ? $iso : 'en';
        $isRtl = $language === 'fa';
        $baseUrl = rtrim($this->context->shop->getBaseURL(true), '/');

        $content = $this->getPageContent($language);
        $images = $this->getReportImages($language, $baseUrl);

        $this->context->smarty->assign([
            'schema_report_language' => $language,
            'schema_report_direction' => $isRtl ? 'rtl' : 'ltr',
            'schema_report_content' => $content,
            'schema_report_images' => $images,
            'schema_report_url' => $baseUrl . '/Schema-JSON-LD',
        ]);

        $this->setTemplate('module:psy_localizer/views/templates/front/schema-json-ld.tpl');
    }

    public function setMedia()
    {
        parent::setMedia();
        $this->context->controller->registerStylesheet(
            'psy-localizer-schema-json-ld',
            $this->module->getPathUri() . 'views/css/front/schema-json-ld.css',
            ['media' => 'all', 'priority' => 100]
        );
    }

    private function getReportImages(string $language, string $baseUrl): array
    {
        $alt = [
            'fa' => [
                'hero' => 'قفسه فروشگاهی شلف بازار برای چیدمان حرفه‌ای فروشگاه',
                'store' => 'قفسه فلزی وسط فروشگاهی شلف بازار',
                'warehouse' => 'قفسه انباری راک سنگین شلف بازار',
            ],
            'en' => [
                'hero' => 'ShelfBazar retail shelving for professional store display',
                'store' => 'ShelfBazar metal supermarket shelving',
                'warehouse' => 'ShelfBazar heavy-duty warehouse racking',
            ],
            'fr' => [
                'hero' => 'Rayonnage de magasin ShelfBazar pour une présentation professionnelle',
                'store' => 'Rayonnage métallique de magasin ShelfBazar',
                'warehouse' => 'Rayonnage industriel lourd ShelfBazar',
            ],
            'es' => [
                'hero' => 'Estantería comercial ShelfBazar para una presentación profesional',
                'store' => 'Estantería metálica comercial ShelfBazar',
                'warehouse' => 'Estantería industrial pesada ShelfBazar',
            ],
        ];

        $a = $alt[$language] ?? $alt['en'];

        return [
            [
                'src' => $baseUrl . '/1458-superlarge_default/arman-shelf.jpg',
                'alt' => $a['hero'],
                'class' => 'schema-report__image--hero',
            ],
            [
                'src' => $baseUrl . '/1042-superlarge_default/26-persia20.jpg',
                'alt' => $a['store'],
                'class' => '',
            ],
            [
                'src' => $baseUrl . '/1151-superlarge_default/Heavy-rock-storage-rack.jpg',
                'alt' => $a['warehouse'],
                'class' => '',
            ],
        ];
    }

    private function getPageContent(string $language): array
    {
        $content = [
            'fa' => [
                'eyebrow' => 'شلف بازار | تجربه‌ای حرفه‌ای برای فروش آنلاین',
                'title' => 'شلف بازار؛ جایی برای ساختن یک تجربه بهتر از خرید آنلاین',
                'lead' => 'شلف بازار با تمرکز بر تجربه کاربری، ارائه شفاف اطلاعات و دسترسی ساده به محصولات، تلاش می‌کند مسیر انتخاب و خرید را برای مشتریان کوتاه‌تر و مطمئن‌تر کند.',
                'cta' => 'مشاهده شلف بازار',
                'intro_title' => 'چرا شلف بازار؟',
                'intro' => 'در یک فروشگاه اینترنتی حرفه‌ای، فقط تنوع کالا مهم نیست؛ نحوه ارائه اطلاعات، سرعت پیدا کردن محصول و سادگی مسیر خرید نیز بخشی از تجربه مشتری است. شلف بازار با همین نگاه، فروشگاه را به فضایی منظم‌تر و قابل‌اعتمادتر برای جست‌وجو، مقایسه و انتخاب تبدیل می‌کند.',
                'cards' => [
                    ['title' => 'انتخاب ساده‌تر', 'text' => 'دسترسی منظم به محصولات و اطلاعات کاربردی کمک می‌کند مشتری سریع‌تر به گزینه مناسب برسد.'],
                    ['title' => 'تجربه کاربری روان', 'text' => 'ساختار صفحه‌ها با هدف کاهش پیچیدگی و ایجاد مسیر روشن‌تر از مشاهده محصول تا خرید طراحی شده است.'],
                    ['title' => 'نگاه حرفه‌ای به فروش آنلاین', 'text' => 'شلف بازار تلاش می‌کند میان ارائه حرفه‌ای، محتوای کاربردی و نیاز واقعی خریدار تعادل ایجاد کند.'],
                ],
                'story_title' => 'یک ویترین دیجیتال، فراتر از یک فهرست محصول',
                'story' => 'امروز مشتری پیش از خرید، تحقیق می‌کند، مقایسه می‌کند و به جزئیات توجه دارد. به همین دلیل یک فروشگاه موفق باید بیش از نمایش کالا عمل کند؛ باید اطلاعات را درست، قابل فهم و در زمان مناسب در اختیار کاربر قرار دهد. شلف بازار با همین رویکرد، تجربه‌ای نزدیک‌تر به یک ویترین حرفه‌ای و مدرن ایجاد می‌کند.',
                'highlight' => 'انتخاب خوب از جایی شروع می‌شود که اطلاعات خوب، ساده و قابل اعتماد در اختیار شما باشد.',
                'closing_title' => 'شلف بازار را ببینید',
                'closing' => 'اگر به دنبال تجربه‌ای منظم، ساده و حرفه‌ای برای جست‌وجو و انتخاب محصولات هستید، شلف بازار را بررسی کنید.',
                'home' => 'ورود به شلف بازار',
            ],
            'en' => [
                'eyebrow' => 'ShelfBazar | A smarter online shopping experience',
                'title' => 'ShelfBazar: A better way to discover and shop online',
                'lead' => 'ShelfBazar focuses on a clear product experience, useful information and an easier path from discovery to purchase.',
                'cta' => 'Visit ShelfBazar',
                'intro_title' => 'Why ShelfBazar?',
                'intro' => 'A professional online store is about more than product variety. The way information is presented, products are discovered and choices are compared all shape the customer experience. ShelfBazar brings these elements together in a cleaner, more practical shopping environment.',
                'cards' => [
                    ['title' => 'Easier discovery', 'text' => 'Organized products and useful information help shoppers reach the right option with less effort.'],
                    ['title' => 'A smoother journey', 'text' => 'Clear page structure helps reduce friction from the first product view to the final purchase decision.'],
                    ['title' => 'A professional approach', 'text' => 'ShelfBazar balances presentation, useful content and real customer needs to create a more thoughtful store experience.'],
                ],
                'story_title' => 'A digital storefront, not just a product list',
                'story' => 'Today, customers research, compare and look closely at details before buying. A modern store therefore needs to do more than display products. It should make important information easy to understand and available at the right moment. ShelfBazar follows this approach to create a more polished and useful digital storefront.',
                'highlight' => 'A better choice starts with information that is clear, useful and easy to trust.',
                'closing_title' => 'Explore ShelfBazar',
                'closing' => 'If you are looking for a clean, practical and professional way to discover products, take a closer look at ShelfBazar.',
                'home' => 'Go to ShelfBazar',
            ],
            'fr' => [
                'eyebrow' => 'ShelfBazar | Une expérience d’achat en ligne plus claire',
                'title' => 'ShelfBazar : une nouvelle façon de découvrir et choisir en ligne',
                'lead' => 'ShelfBazar met l’accent sur une présentation claire, des informations utiles et un parcours plus simple entre découverte et achat.',
                'cta' => 'Découvrir ShelfBazar',
                'intro_title' => 'Pourquoi ShelfBazar ?',
                'intro' => 'Une boutique en ligne professionnelle ne se limite pas à proposer de nombreux produits. La manière de présenter les informations, de rechercher et de comparer les produits joue également un rôle essentiel dans l’expérience client.',
                'cards' => [
                    ['title' => 'Une découverte plus simple', 'text' => 'Des produits organisés et des informations utiles facilitent la recherche et la sélection.'],
                    ['title' => 'Un parcours fluide', 'text' => 'Une structure claire réduit les obstacles entre la découverte d’un produit et la décision d’achat.'],
                    ['title' => 'Une approche professionnelle', 'text' => 'ShelfBazar cherche un équilibre entre présentation, contenu utile et besoins réels des clients.'],
                ],
                'story_title' => 'Une vitrine numérique, bien plus qu’une liste de produits',
                'story' => 'Les clients recherchent, comparent et vérifient les détails avant d’acheter. Une boutique moderne doit donc aller au-delà de l’affichage des produits et rendre les informations importantes faciles à comprendre au bon moment.',
                'highlight' => 'Un bon choix commence par une information claire, utile et fiable.',
                'closing_title' => 'Découvrez ShelfBazar',
                'closing' => 'Pour une expérience de découverte et de sélection plus claire et professionnelle, découvrez ShelfBazar.',
                'home' => 'Accéder à ShelfBazar',
            ],
            'es' => [
                'eyebrow' => 'ShelfBazar | Una experiencia de compra online más clara',
                'title' => 'ShelfBazar: una mejor forma de descubrir y comprar online',
                'lead' => 'ShelfBazar apuesta por una presentación clara, información útil y un recorrido sencillo desde el descubrimiento hasta la compra.',
                'cta' => 'Visitar ShelfBazar',
                'intro_title' => '¿Por qué ShelfBazar?',
                'intro' => 'Una tienda online profesional es mucho más que un catálogo amplio. La forma de presentar la información, encontrar productos y comparar opciones también forma parte de la experiencia del cliente.',
                'cards' => [
                    ['title' => 'Descubrimiento sencillo', 'text' => 'Productos organizados e información útil ayudan a encontrar la opción adecuada con menos esfuerzo.'],
                    ['title' => 'Un recorrido más fluido', 'text' => 'Una estructura clara reduce la fricción desde la primera visita al producto hasta la decisión de compra.'],
                    ['title' => 'Una visión profesional', 'text' => 'ShelfBazar busca equilibrar presentación, contenido útil y necesidades reales de los clientes.'],
                ],
                'story_title' => 'Un escaparate digital, mucho más que una lista de productos',
                'story' => 'Los clientes investigan, comparan y revisan detalles antes de comprar. Por eso una tienda moderna debe hacer más que mostrar productos: debe presentar la información importante de forma sencilla y en el momento adecuado.',
                'highlight' => 'Una buena elección comienza con información clara, útil y fiable.',
                'closing_title' => 'Descubre ShelfBazar',
                'closing' => 'Si buscas una forma clara, práctica y profesional de descubrir productos, conoce ShelfBazar.',
                'home' => 'Ir a ShelfBazar',
            ],
        ];

        return $content[$language] ?? $content['en'];
    }
}
