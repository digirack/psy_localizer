<?php
/**
 * Prestashop localizer
 * Comprehensive localization of Prestashop specifically tailored for the Persian language and the Iranian market.
 *
 * @author Hashem Afkhami <hashemafkhami89@gmail.com>
 * @copyright (c) 2025 - PrestaYar Team
 * @website https://prestayar.com
 */
declare(strict_types=1);

namespace PrestaYar\Localizer\Native;

use Morilog\Jalali\Jalalian;
use Morilog\Jalali\CalendarUtils;
use PrestaShop\PrestaShop\Core\Grid\Data\GridData;
use PrestaShop\PrestaShop\Core\Grid\Record\RecordCollection;

class NativeCorePrestashop
{
    public static function fixCurrency(): bool|int
    {
        $lang_id = \Language::getIdByIso('fa');
        if (empty($lang_id)) {
            return -10;
        }

        $currencyId = \Currency::getIdByIsoCode('IRT');
        if (!empty($currencyId)) {
            $currencyToman = new \Currency($currencyId, $lang_id);

            $currencyToman->name = 'تومان ایران';
            $currencyToman->symbol = 'تومان';
            $currencyToman->pattern = '#,##0.00 ¤';

            if (empty($currencyToman->save())) {
                return -12;
            }

            return true;
        }

        $new = new \Currency();
        foreach (\Language::getLanguages() as $lang){
            if ($lang['iso_code'] == 'fa') {
                $new->name[$lang['id_lang']] = 'تومان ایران';
                $new->symbol[$lang['id_lang']] = 'تومان';
            } else {
                $new->name[$lang['id_lang']] = 'Iranian Toman';
                $new->symbol[$lang['id_lang']] = 'IRT';
            }
            $new->pattern = '#,##0.00 ¤';
        }

        $new->iso_code = 'IRT';
        $new->numeric_iso_code = 365;
        $new->precision = 0;
        $new->conversion_rate = 1.0;
        $new->deleted = 0;
        $new->active = 1;

        if (empty($new->add())) {
            return -11;
        }

        return true;
    }

    /**
     * Convert date for save in the database
     * @param $object
     */
    public function convertDate($object)
    {
        if (!\Configuration::get('Localizer_Native_Active')) {
            return;
        }

        if (!empty(\Configuration::get('Localizer_JalaliDate'))) {
            $class_name = get_class($object);
            $definition = \ObjectModel::getDefinition($class_name);

            if (!empty($definition['fields'])) {
                foreach ($definition['fields'] as  $field => $def)
                {
                    if (isset($def['validate']) && in_array($def['validate'], array('isDate', 'isDateFormat', 'isBirthDate')))
                    {
                        $date = $object->$field;
                        if ($date == '0000-00-00 00:00:00' || $date == '0000-00-00' || !$date) {
                            continue;
                        }

                        $object->$field = $this->getDateGregorian($date);
                    }
                }
            }
        }
    }

    public function getDateGregorian($date)
    {
        $dateArray = $this->getDateArray($date);
        if (empty($dateArray) || count($dateArray) < 3) {
            return $date;
        }

        $jy = $dateArray['year'];
        if (!($jy >= 1900 && $jy <= 2100)){
            $date = CalendarUtils::toGregorian($dateArray['year'], $dateArray['month'], $dateArray['day']);
            $gDate = sprintf("%04d", intval($date[0]) ) . '-' .
                     sprintf("%02d", intval($date[1]) ) . '-' .
                     sprintf("%02d", intval($date[2]) );

            $gTime = isset($dateArray['hour']) ? ' '. $dateArray['hour'].':'.$dateArray['minute'].':'.$dateArray['second'] : '';

            return $gDate . $gTime;
        }

        return $date;
    }

    public function getDateArray($date = null)
    {
        if (empty($date)) {
            return false;
        }

        $dateParts = explode("/", $date);
        if (count($dateParts) > 1) {
            // '2017/07/10
            $dateParts = explode("/", $date);
            return [
                "year"      => sprintf("%04d", intval($dateParts[0])),
                "month"     => sprintf("%02d", intval($dateParts[1])),
                "day"       => sprintf("%02d", intval($dateParts[2]))
            ];
        } else {
            //hour, minute, second, month, day, year
            $dateParts = explode(" ", $date);
            $dataDateParts = explode("-", $dateParts[0]);

            if (count($dateParts) > 1) {
                // '2017-07-10 15:00:00'
                $dataTimeParts = explode(":", $dateParts[1]);
                return [
                    "year"      => sprintf("%04d", intval($dataDateParts[0])),
                    "month"     => sprintf("%02d", intval($dataDateParts[1])),
                    "day"       => sprintf("%02d", intval($dataDateParts[2])),
                    "hour"      => sprintf("%02d", intval($dataTimeParts[0])),
                    "minute"    => sprintf("%02d", intval($dataTimeParts[1])),
                    "second"    => sprintf("%02d", intval($dataTimeParts[2]))
                ];
            } else {
                // '2017-07-10
                return [
                    "year"      => sprintf("%04d", intval($dataDateParts[0])),
                    "month"     => sprintf("%02d", intval($dataDateParts[1])),
                    "day"       => sprintf("%02d", intval($dataDateParts[2]))
                ];
            }
        }
    }

    public function getDataModifiedRecords($data)
    {
        $records = [];
        foreach ($data->getRecords()->all() as $record) {
            foreach ($record as $key => $value) {
                if (!\Validate::isDate($value)) {
                    continue;
                }

                $date = strtotime($value);
                if (!empty($date) && $date > 0) {
                    $record[$key] = Jalalian::forge($date)->format('Y-m-d H:i:s');
                }
            }
            $records[] = $record;
        }

        return new GridData(
            new RecordCollection($records),
            $data->getRecordsTotal(),
            $data->getQuery()
        );
    }

}
