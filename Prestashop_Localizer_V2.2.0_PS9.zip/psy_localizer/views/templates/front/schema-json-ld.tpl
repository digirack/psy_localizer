{extends file='page.tpl'}

{block name='page_title'}{$schema_report_content.title|escape:'htmlall':'UTF-8'}{/block}

{block name='page_content'}
<div class="schema-report schema-report--{$schema_report_language|escape:'htmlall':'UTF-8'}" dir="{$schema_report_direction|escape:'htmlall':'UTF-8'}">
  <section class="schema-report__hero">
    <div class="schema-report__hero-glow" aria-hidden="true"></div>
    <div class="schema-report__container">
      <div class="schema-report__hero-copy">
        <div class="schema-report__eyebrow">{$schema_report_content.eyebrow|escape:'htmlall':'UTF-8'}</div>
        <h1>{$schema_report_content.title|escape:'htmlall':'UTF-8'}</h1>
        <p class="schema-report__lead">{$schema_report_content.lead|escape:'htmlall':'UTF-8'}</p>
        <a class="schema-report__cta" href="https://shelfbazar.com/" target="_blank" rel="noopener noreferrer">{$schema_report_content.cta|escape:'htmlall':'UTF-8'} <span aria-hidden="true">↗</span></a>
      </div>
      <div class="schema-report__hero-image-wrap">
        <img class="schema-report__hero-image" src="{$schema_report_images.0.src|escape:'htmlall':'UTF-8'}" alt="{$schema_report_images.0.alt|escape:'htmlall':'UTF-8'}" width="1200" height="800" loading="eager" decoding="async">
      </div>
    </div>
  </section>

  <main class="schema-report__container schema-report__body">
    <section class="schema-report__intro">
      <div class="schema-report__section-label">ShelfBazar</div>
      <h2>{$schema_report_content.intro_title|escape:'htmlall':'UTF-8'}</h2>
      <p>{$schema_report_content.intro|escape:'htmlall':'UTF-8'}</p>
    </section>

    <section class="schema-report__cards" aria-label="ShelfBazar highlights">
      {foreach from=$schema_report_content.cards item=card}
        <article class="schema-report__card">
          <span class="schema-report__card-number">0{$card@iteration}</span>
          <h3>{$card.title|escape:'htmlall':'UTF-8'}</h3>
          <p>{$card.text|escape:'htmlall':'UTF-8'}</p>
        </article>
      {/foreach}
    </section>

    <section class="schema-report__story">
      <div>
        <div class="schema-report__section-label">ShelfBazar</div>
        <h2>{$schema_report_content.story_title|escape:'htmlall':'UTF-8'}</h2>
      </div>
      <p>{$schema_report_content.story|escape:'htmlall':'UTF-8'}</p>
    </section>

    <section class="schema-report__gallery" aria-label="ShelfBazar products and solutions">
      <figure class="schema-report__gallery-item schema-report__gallery-item--wide">
        <img src="{$schema_report_images.1.src|escape:'htmlall':'UTF-8'}" alt="{$schema_report_images.1.alt|escape:'htmlall':'UTF-8'}" width="1200" height="800" loading="lazy" decoding="async">
      </figure>
      <figure class="schema-report__gallery-item">
        <img src="{$schema_report_images.2.src|escape:'htmlall':'UTF-8'}" alt="{$schema_report_images.2.alt|escape:'htmlall':'UTF-8'}" width="1200" height="800" loading="lazy" decoding="async">
      </figure>
    </section>

    <section class="schema-report__highlight">
      <span aria-hidden="true">“</span>
      <p>{$schema_report_content.highlight|escape:'htmlall':'UTF-8'}</p>
    </section>

    <section class="schema-report__closing">
      <h2>{$schema_report_content.closing_title|escape:'htmlall':'UTF-8'}</h2>
      <p>{$schema_report_content.closing|escape:'htmlall':'UTF-8'}</p>
      <a class="schema-report__cta schema-report__cta--dark" href="https://shelfbazar.com/" target="_blank" rel="noopener noreferrer">{$schema_report_content.home|escape:'htmlall':'UTF-8'} <span aria-hidden="true">↗</span></a>
    </section>
  </main>
</div>
{/block}
